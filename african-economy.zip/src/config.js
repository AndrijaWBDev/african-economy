export const INFURA_KEY = "1b4c44fdf5a0404b91ee1a85db0aed9a";
export const BACKEND_URL = "http://localhost:5000";
export const PROJECT_DOMAINS = [
    "Education",
    "Health",
    "Environment",
    "fight against counterfeiting",
    "fight aginst food insufficiency"
]